const express = require('express');
const mysql = require('mysql');
const app = express();
const dotenv = require('dotenv');
const path= require('path')

dotenv.config({path: './.env'});

const db = mysql.createConnection({
    host: process.env.DB_host,
    user: process.env.DB_user,
    password: process.env.DB_password,
    database: process.env.DB
});

//routes
app.use(express.urlencoded({extended: false}));
app.use(express.json());
app.use('/',require('./routes/pages'));
app.use('/auth',require('./routes/auth'));


app.listen(3400, ()=>{
    console.log("server on port 3400");
});

const publicDirectory = path.join(__dirname,'/public')
console.log(publicDirectory);
app.set('view engine', 'hbs');

app.use(express.static(publicDirectory));


db.connect( (err) =>{
    if(err) throw err;
    else{
        console.log('mysql connected');
    }
})


