const mysql = require('mysql');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs')


const db = mysql.createConnection({
    host: process.env.DB_host,
    user: process.env.DB_user,
    password: process.env.DB_password,
    database: process.env.DB
});


exports.register = (req,res) =>{
    console.log(req.body);
    const {name,password,passwordConfirm} = req.body;
    db.query('SELECT name FROM users WHERE name = ?',[name],async (err,results) =>{
        if(err) throw err;
        if(results.length>0){
            return res.render('register',{
                message:'Ce nom est déja pris'
            })
        }
        else if(password !== passwordConfirm ){
            return res.render('register',{
                message:'Mot de passe incorrect'
            })
        }

        //let hashedPassword = await bcrypt.hash(password, 8);
        //console.log(hashedPassword);
    })
}