let bateaux=(function(){
    console.log("bateaux") 
})();